DISALLOWED = {"N.A.T.O",
"NATO",
"N.A.T.O.",}
#may be allowed in the future
